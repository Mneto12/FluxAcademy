CREATE DATABASE IF NOT EXISTS `bfcbdvyi6ggtzay9cgor`;

USE `bfcbdvyi6ggtzay9cgor`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cursos`;

CREATE TABLE `cursos` (
  `idCurso` int NOT NULL AUTO_INCREMENT,
  `nombre_curso` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(300) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `duracion` int NOT NULL DEFAULT '0',
  `imagen` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `video` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idCurso`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cursos` VALUES (113,"Curso de Python","Curso donde podrás introducirte al mundo de Python y a la lógica de su programación.",12,"curso_python.jpg","curso_python.mp4"),
(114,"Curso de HTML y CSS","Intégrate en el mundo de paginas web con los lenguajes HTML y CSS. Este curso te proporciona todas las herramientas.",8,"html_css.jpg","html_css.mp4"),
(115,"Introducción a la Programación","Aprende con nosotros sobre la lógica y la estructura de la programación general.",20,"introduccion_programacion.png","introduccion_programacion.mp4"),
(116,"Boostrap Framework","Uno de los frameworks más utilizados en la actualidad. Inscríbete y aprende a realizar tu propia página web con Boostrap.",36,"curso_boostrap.jpg","curso_boostrap.mp4"),
(117,"Introducción a lenguaje C++","Curso de lenguaje C++ para programadores Juniors. Público principiante que desea aprender lo más básico.",18,"curso_cplus.jpg","curso_cplus.mp4"),
(118,"Curso de Java","Te enseñamos sobre la programación orientada a objetos en Java y creación de interfaces gráficas",24,"curso_java.jpg","curso_java.mp4"),
(119,"Aprende JavaScript","Mejor conocido como JS, es un lenguaje que te ayudará a agregar funcionalidades a tu página web y a modernizar la misma.",6,"curso_js.jpg","curso_js.mp4"),
(120,"Base de Datos MySQL","Aprende sobre la sintaxis y las diferentes funcionalidades que te ofrecen las bases de datos a tus aplicaciones y paginas web.",22,"curso_mysql.jpg","curso_mysql.mp4"),
(121,"Desarrolla Paginas Web","Crea tu propia pagina web con nosotros. Te mostramos el lenguaje de etiquetas HTML, paginas de estilos CSS y frameworks de programación.",28,"curso_paginaweb.jpg","curso_paginaweb.mp4");


DROP TABLE IF EXISTS `matricula`;

CREATE TABLE `matricula` (
  `idInscripcion` int NOT NULL AUTO_INCREMENT,
  `creado` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `idCurso` int NOT NULL,
  `idUsuario` int NOT NULL,
  PRIMARY KEY (`idInscripcion`),
  UNIQUE KEY `idCurso_idUsuario` (`idCurso`,`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `matricula` VALUES (36,"2022-08-01 20:10:23",119,160),
(37,"2022-08-01 20:56:23",120,166),
(38,"2022-08-03 02:57:05",119,165);


DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `idUsuario` int NOT NULL AUTO_INCREMENT,
  `cedula` int NOT NULL DEFAULT '0',
  `nombre` varchar(15) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `apellido` varchar(15) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `genero` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `fecha_nacimiento` date NOT NULL,
  `nombre_usuario` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `correo` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `contrasena` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `imagen` varchar(50) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `pregunta` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `respuesta` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`idUsuario`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuario` VALUES (158,30064273,"Miguel","Urdaneta","Masculino","2002-05-02","miguelurd","miguelurdanetar02@gmail.com","Miguel10!","perfilmiguel.jpg","",""),
(159,25631478,"Claudia","Linares","Femenino","1998-07-01","claudia_15","claudialineras@gmail.com","Claudia@2","perfil1.jpg","",""),
(160,27896541,"Fabricio","Luengo","Masculino","1993-08-03","Fabio18","fabiocursos@gmail.com","Fabricio!12","perfil4.jpeg","",""),
(161,22636545,"Robert","Villas","Masculino","1990-09-10","Villas.Robert","villas10@gmail.com","Villas$15","perfil2.jpeg","",""),
(162,30625958,"Elizabeth","Mendez","Femenino","2001-12-05","Lisashi14","lisashimendez@gmail.com","Lisashi@24","perfil5.jpg","",""),
(163,27541563,"Carlos","Rodriguez","Masculino","1999-01-12","Carlitos25","carlosr12@gmail.com","Carlangas@4000","perfil3.jpg","",""),
(164,23654987,"Amalia","Martinez","Femenino","1996-02-01","Amimartinez","amimartinez@gmail.com","Martinez!ami13","perfil6.jpg","",""),
(166,29882740,"Miguel","Coronel","Masculino","2000-04-12","MiguelTox2112","envenezuela2000@gmail.com","Miguel2112##","perfilcoronel.jpg","",""),
(167,28467267,"Lisandro","Hernandez","Masculino","2002-06-24","Lisandrohr","lisandrohernandezramirez@gmail.com",1234567,"perfillisandro.jpeg","Mascota","pinky"),
(171,25362251,"Mario","Portillo","Masculino","2003-06-18","MarioP","soymariop@gmail.com","Maria2112@","perfilM.jpeg","Comida Favorita","Pizza"),
(172,30393006,"Asunción","Bellomo","Femenino","2002-05-11","vicky.bellomo","victoriabellomo7@hotmail.com","Spadinky5!","foto.jpg","Nombre de mi mascota","Spyke");


SET foreign_key_checks = 1;
