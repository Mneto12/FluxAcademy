CREATE DATABASE IF NOT EXISTS `cursonline`;

USE `cursonline`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `cursos`;

CREATE TABLE `cursos` (
  `idCurso` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_curso` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  `duracion` int(3) NOT NULL DEFAULT '0',
  `imagen` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `video` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idCurso`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `cursos` VALUES (54,"aaaaaa","aaaaaa",10,"avatar3.png",NULL),
(73,"c++","nose",12,"avatar3.png",NULL),
(75,"prueba","nose",123,"avatar3.png",NULL),
(76,"prueba","nose",12,"avatar3.png",NULL),
(77,"prueba","noseaaa",12,"avatar3.png",NULL),
(78,"pyton","adios",123,"avatar3.png",NULL),
(79,"pyton","adios",123,"avatar1.png",NULL),
(80,"pyton","adios",123,"avatar2.png",NULL),
(81,"prueba","adios",12,"avatar3.png",NULL),
(82,"prueba","adios",12,"avatar3.png",NULL),
(91,"prueba","foto",20,"avatar3.png",NULL),
(92,"prueba curso","no se no se",45,"avatar.png",""),
(93,"cambiar card","prueba meet del proyecto edicion",10,"avatar.png",""),
(95,"Pascal","aaaaa",12,"Miguel_Coronel.png",""),
(97,"prueba","aaa",12,"feriadecomida.jpg",""),
(99,"c++6","ggg",20,"subir.png","Curso Java desde cero  2.mp4"),
(100,"pyton","nmbmbnm",20,"pngwing.com (1).png",""),
(101,"prueba","dhh",43,"AsuncioÌn_Bellomo.png","pexels-mark-mccammon-1080721.jpg"),
(104,"c++","j",12,"raamin-ka-uR51HXLO7G0-unsplash.jpg","y2mate.com - Kawaguchi Yurina  Look At Me Korean VerMV_v144P.mp4"),
(110,"funciona el cambio","dfgdfgdf",13,"emmanuel-ikwuegbu-hepvMrLVx8c-unsplash.jpg","emmanuel-ikwuegbu-hepvMrLVx8c-unsplash.jpg");


DROP TABLE IF EXISTS `matricula`;

CREATE TABLE `matricula` (
  `idInscripcion` int(11) NOT NULL AUTO_INCREMENT,
  `creado` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `idCurso` int(11) NOT NULL,
  `idUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idInscripcion`),
  UNIQUE KEY `idCurso_idUsuario` (`idCurso`,`idUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `matricula` VALUES (12,"2022-07-23 04:44:16",99,8),
(13,"2022-07-23 04:44:41",95,8),
(14,"2022-07-23 05:07:45",110,8),
(15,"2022-07-23 22:43:23",101,8),
(16,"2022-07-24 02:21:25",104,8),
(17,"2022-07-24 02:22:55",76,8),
(18,"2022-07-24 02:25:06",97,8),
(19,"2022-07-24 02:31:33",92,8),
(20,"2022-07-24 02:32:06",80,8),
(21,"2022-07-24 15:54:07",100,8);


DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL DEFAULT '0',
  `nombre` varchar(15) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `apellido` varchar(15) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `genero` varchar(10) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `fecha_nacimiento` date NOT NULL,
  `nombre_usuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `correo` varchar(50) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `contrasena` varchar(20) COLLATE utf8_spanish_ci NOT NULL DEFAULT '0',
  `imagen` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idUsuario`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `usuario` VALUES (1,3232332,"maria","se","fe","2020-07-17","manana","asddasd","asdasd",NULL),
(2,11111111,"maria","rangel","femenino","1972-08-01","hoas","holas@gamil.com",12345,NULL),
(3,11111111,"maria","rangel","femenino","1972-08-01","hoas","holas@gamil.com",12345,NULL),
(5,15673542,"Maria ","Sapio","femenino","1972-12-01","lupita","buenas@tin.com",123,NULL),
(6,15673542,"Maria ","Sapio","femenino","1971-09-01","lupita","hola@gmail.com",123456,NULL),
(7,1456,"carla","carmen","masculino","1982-02-03","claudia","hol@gmail.com",1234567,"user7-128x128.jpg"),
(8,12345,"Miguel","Urdaneta","Masculino","2010-06-03","miguel","miguel@gmail.com",12345,"Miguel_Urdaneta (1).png"),
(9,15673542,"Maria ","Sapio","femenino","2022-07-22","lupita","buenas@tin.com",123456,"user8-128x128.jpg"),
(10,32443,"fsddfsdaf","dfasdf","femenino","2022-07-21","afsdf","hola@gmail.com",21,"user2-160x160.jpg"),
(11,323,"gdfgf","sdfgdf","femenino","2022-07-21","fdsf","buenas@tin.com",43,"testimonials-1.jpeg"),
(12,435453,"gsrg","erwtert","femenino","2022-07-15","wrtwrty","buenas@tin.com",34434,"Imagen1.jpg"),
(40,435453,"Maria Quintero","Sapio","femenino","2022-07-14","lupita","buenas@tin.com",34434,"Miguel_Coronel.png"),
(41,15673542,"Maria ","Sapio","femenino","2022-06-30","lupita","hola@gmail.com",123,"pngwing.com (2).png"),
(42,15673542,"Maria ","Sapio","femenino","2022-07-13","lupita","hola@gmail.com",123456,"Lisandro_Hernandez.png"),
(43,2323,"Miguel ","saaaa","femenino","2022-07-21","lupita","hola@gmail.com","sara","Miguel_Coronel.png"),
(44,15673542,"Mileida Godoy","Sapio","femenino","2022-07-06","lupita","hola@gmail.com",123,"datos.png"),
(45,2312,"Maria ","Sapio","femenino","2022-07-14","lupita","hola@gmail.com",123,"card1.png"),
(46,111,"asdasdas","asdasdas","femenino","2022-07-12","lupita","hola@gmail.com",123,"token.png"),
(47,1111,"asdfsdf","dsafsdfds","femenino","2022-07-05","lupita","hola@gmail.com",123,"token.png"),
(48,3414534,"vsdvdaf","fdafgafgadfgadf","femenino","2022-07-15","","","","diagrama.png"),
(49,3414534,"vsdvdaf","fdafgafgadfgadf","femenino","2022-07-15","","","","diagrama.png"),
(50,3414534,"vsdvdaf","fdafgafgadfgadf","femenino","2022-07-15","","","","diagrama.png"),
(51,3414534,"vsdvdaf","fdafgafgadfgadf","femenino","2022-07-15","","","","diagrama.png"),
(52,3414534,"vsdvdaf","fdafgafgadfgadf","femenino","2022-07-15","","","","diagrama.png"),
(53,324343,"dfvdfsvdfvsdf","fvsdfsdfvdf","","2022-07-15","","alosno@gmail.com","rf43q444t4","foto2.png"),
(54,324343,"dfvdfsvdfvsdf","fvsdfsdfvdf","","2022-07-15","","alosno@gmail.com","rf43q444t4","foto2.png"),
(55,324343,"dfvdfsvdfvsdf","fvsdfsdfvdf","","2022-07-15","","alosno@gmail.com","rf43q444t4","foto2.png"),
(56,324343,"dfvdfsvdfvsdf","fvsdfsdfvdf","","2022-07-15","","alosno@gmail.com","rf43q444t4","foto2.png"),
(57,3243,"fdsfgsdf","fdsgdf","femenino","2022-07-20","fdgdfgdf","alosn@gmail.com","dsadfsdfadf","token.png"),
(58,546546,"hgdfhgh","dfhfhfg","Masculino","2022-07-06","fgdhfghgf","ssksks@gmail.com",111111,"datos.png"),
(59,4334,"sdfgfdsgd","fdsdfgsdf","Masculino","2022-07-06","sdfgdfgdfg","fgsdg@hg.com","ffdg33443","etherum.png"),
(60,3243423,"dfasdfs","dffasdfasd","Femenino","2022-07-14","sadfsdf","sdaffdsd","dsfasdf","token.png"),
(61,15673542,"Maria  J","Sapio","Femenino","2022-07-20","lupita","buenas@tin.com",43,"foto.png"),
(62,123123,"pruebafoto","fotoprueba","Femenino","2022-07-14","asdasdasd","asdasd@gmail.com",123123,""),
(63,123123,"pruebafoto","fotoprueba","Femenino","2022-07-14","asdasdasd","asdasd@gmail.com",123123,""),
(64,123123,"pruebafoto","fotoprueba","Femenino","2022-07-14","asdasdasd","asdasd@gmail.com",123123,""),
(66,13123,"asdasd","asdasd","Femenino","2022-07-13","prueba","prueba@gmail.com",123123,"etherum.png"),
(67,123123,"alpaco","rutenio","Masculino","2022-07-07","asdasd","miguel@gmail.com",123123,"WhatsApp Image 2022-05-28 at 12.10.03 PM (1).jpeg"),
(68,123123,"carlos","gonzales","Masculino","2022-07-08","carlitos","carlos@gmail.com","carlitos","35ed10_2b5799c23d59432780182aa25a77a90b_mv2.jpg");


SET foreign_key_checks = 1;
